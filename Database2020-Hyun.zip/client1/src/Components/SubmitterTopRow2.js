import React from "react";

import styles from "../CSS/component.module.css";

export const SubmitterTopRow2 = () => {
  return (
    <div className={styles.outer_row}>
      <p>태스크 이름</p>
      <p>설명</p>
      <p></p>
    </div>
  );
};
